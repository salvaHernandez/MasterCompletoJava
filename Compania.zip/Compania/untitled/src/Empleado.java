public class Empleado extends Persona {
    // Atributos adicionales
    private String departamento;
    private double remuneracion;
    private int empleadoId;

    // Constructor
    public Empleado(String nombre, String apellido, String numeroFiscal, String direccion, String departamento, double remuneracion, int empleadoId) {
        super(nombre, apellido, numeroFiscal, direccion);
        this.departamento = departamento;
        this.remuneracion = remuneracion;
        this.empleadoId = empleadoId;
    }

    // Getters
    public String getDepartamento() {
        return departamento;
    }

    public double getRemuneracion() {
        return remuneracion;
    }

    public int getEmpleadoId() {
        return empleadoId;
    }

    // Setters
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public void setRemuneracion(double remuneracion) {
        this.remuneracion = remuneracion;
    }

    public void setEmpleadoId(int empleadoId) {
        this.empleadoId = empleadoId;
    }

    // toString
    @Override
    public String toString() {
        return "Empleado: " + super.toString() + ", Departamento: " + departamento + ", Remuneración: " + remuneracion + ", Empleado ID: " + empleadoId;
    }
}
