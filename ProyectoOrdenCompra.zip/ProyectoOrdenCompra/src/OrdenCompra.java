import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrdenCompra {
    // Atributos
    private static int contadorId = 0;
    private int id;
    private String descripcion;
    private LocalDate fecha;
    private Cliente cliente;
    private List<Producto> productos;

    // Constructor
    public OrdenCompra(String descripcion) {
        this.id = ++contadorId; // Autoincremental
        this.descripcion = descripcion;
        this.productos = new ArrayList<>();
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    // Setters
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    // Métodos adicionales
    public void addProducto(Producto producto) {
        this.productos.add(producto);
    }

    public void imprimirOrden() {
        System.out.println("Orden ID: " + getId());
        System.out.println("Descripción: " + getDescripcion());
        System.out.println("Fecha: " + getFecha());
        System.out.println("Cliente: " + getCliente().getNombre() + " " + getCliente().getApellido());
        System.out.println("Productos:");
        for (Producto producto : getProductos()) {
            System.out.println("  - " + producto);
        }
    }

}
