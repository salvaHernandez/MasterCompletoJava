public class Main {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente("Juan", "Pérez", "NF12345", "Calle Falsa 123", 1);
        Empleado empleado1 = new Empleado("Carlos", "López", "NF11111", "Calle Luna 1", "Ventas", 50000.0, 1001);
        Gerente gerente1 = new Gerente("Luis", "Fernández", "NF33333", "Calle Estrella 3", "Ventas", 70000.0, 2001, 1000000.0);

        System.out.println(cliente1);
        System.out.println(empleado1);
        System.out.println(gerente1);
    }
}
