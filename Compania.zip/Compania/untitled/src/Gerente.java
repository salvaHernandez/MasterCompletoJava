public class Gerente extends Empleado {
    // Atributo adicional
    private double presupuesto;

    // Constructor
    public Gerente(String nombre, String apellido, String numeroFiscal, String direccion, String departamento, double remuneracion, int empleadoId, double presupuesto) {
        super(nombre, apellido, numeroFiscal, direccion, departamento, remuneracion, empleadoId);
        this.presupuesto = presupuesto;
    }

    // Getters
    public double getPresupuesto() {
        return presupuesto;
    }

    // Setters
    public void setPresupuesto(double presupuesto) {
        this.presupuesto = presupuesto;
    }

    // toString
    @Override
    public String toString() {
        return "Gerente: " + super.toString() + ", Presupuesto: " + presupuesto;
    }
}
