import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Cliente juan = new Cliente("Juan", "Pérez");
        Cliente maria = new Cliente("María", "García");
        Cliente pepe = new Cliente("Pepe", "Ruiz");

        Producto producto1 = new Producto("Sony", "Televisor", 500);
        Producto producto2 = new Producto("Apple", "iPhone", 999);
        Producto producto3 = new Producto("Dell", "Laptop", 1200);
        Producto producto4 = new Producto("Samsung", "Refrigerador", 800);
        Producto producto5 = new Producto("LG", "Lavadora", 700);
        Producto producto6 = new Producto("HP", "Impresora", 150);
        Producto producto7 = new Producto("Bose", "Altavoz", 300);
        Producto producto8 = new Producto("Microsoft", "Surface Pro", 1100);
        Producto producto9 = new Producto("Nikon", "Cámara", 850);
        Producto producto10 = new Producto("Asus", "Monitor", 250);
        Producto producto11 = new Producto("Logitech", "Teclado", 100);
        Producto producto12 = new Producto("Corsair", "Mouse", 80);

        OrdenCompra orden1 = new OrdenCompra("Primera orden");
        OrdenCompra orden2 = new OrdenCompra("Segunda orden");
        OrdenCompra orden3 = new OrdenCompra("Tercera orden");

        orden1.setCliente(juan);
        orden1.setFecha(LocalDate.now());
        orden2.setCliente(maria);
        orden2.setFecha(LocalDate.now());
        orden3.setCliente(pepe);
        orden3.setFecha(LocalDate.now());

        orden1.addProducto(producto1);
        orden1.addProducto(producto2);
        orden1.addProducto(producto3);
        orden1.addProducto(producto4);

        orden2.addProducto(producto5);
        orden2.addProducto(producto6);
        orden2.addProducto(producto7);
        orden2.addProducto(producto8);

        orden3.addProducto(producto9);
        orden3.addProducto(producto10);
        orden3.addProducto(producto11);
        orden3.addProducto(producto12);

        orden1.imprimirOrden();
        orden2.imprimirOrden();
        orden3.imprimirOrden();
    }
}