public class Cliente extends Persona {
    // Atributo adicional
    private int clienteId;

    // Constructor
    public Cliente(String nombre, String apellido, String numeroFiscal, String direccion, int clienteId) {
        super(nombre, apellido, numeroFiscal, direccion);
        this.clienteId = clienteId;
    }

    // Getters
    public int getClienteId() {
        return clienteId;
    }

    // Setters
    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    // toString
    @Override
    public String toString() {
        return "Cliente: " + super.toString() + ", Cliente ID: " + clienteId;
    }
}
